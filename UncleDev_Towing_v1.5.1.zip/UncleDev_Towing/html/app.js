// UncleDev Towing NUI renderer.
// Lua sends { action: 'open' | 'render' | 'close', view }.
// Clicks and key presses are reported back with fetch() to the resource's NUI callbacks.
(() => {
  const RESOURCE = typeof GetParentResourceName === 'function'
    ? GetParentResourceName()
    : 'UncleDev_Towing';

  const panel = document.getElementById('panel');
  const list = document.getElementById('list');
  const titleEl = document.getElementById('title');
  const subtitleEl = document.getElementById('subtitle');
  const badgeEl = document.getElementById('badge');
  const headIcon = document.getElementById('headIcon');
  const backBtn = document.getElementById('back');
  const closeBtn = document.getElementById('close');

  let canBack = false;

  const ICON_PATHS = {
    truck:   '<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    trailer: '<path d="M2 8h14v8H2z"/><path d="M16 11h4l2 2v3h-6"/><circle cx="6" cy="18" r="1.6"/><circle cx="19" cy="18" r="1.6"/>',
    car:     '<path d="M4 15l1.5-5h13L20 15v3H4z"/><circle cx="7.5" cy="18" r="1.5"/><circle cx="16.5" cy="18" r="1.5"/>',
    plus:    '<path d="M12 5v14M5 12h14"/>',
    unload:  '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    winch:   '<circle cx="12" cy="12" r="4"/><path d="M12 3v5M12 16v5M3 12h5M16 12h5"/>',
    rollback: '<path d="M3 17h11"/><path d="M14 17l6-8"/><path d="M4 14h4"/>',
    impound: '<path d="M4 20V9l8-5 8 5v11"/><path d="M9 20v-6h6v6"/>',
    alert:   '<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17v.5"/>',
    back:    '<path d="M15 6l-6 6 6 6"/>',
    close:   '<path d="M6 6l12 12M18 6L6 18"/>'
  };

  function setIcon(el, key) {
    const paths = ICON_PATHS[key] || ICON_PATHS.car;
    // Only trusted, static markup from ICON_PATHS is ever written here.
    el.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
  }

  function post(name, data) {
    fetch(`https://${RESOURCE}/${name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data || {})
    }).catch(() => {});
  }

  function makeItem(item) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'item';
    btn.setAttribute('role', 'listitem');
    btn.dataset.tone = item.tone || 'info';
    btn.disabled = !!item.disabled;

    const icon = document.createElement('span');
    icon.className = 'item-icon';
    setIcon(icon, item.icon);

    const body = document.createElement('span');
    body.className = 'item-body';

    const title = document.createElement('span');
    title.className = 'item-title';
    title.textContent = item.title || '';
    body.append(title);

    if (item.subtitle) {
      const sub = document.createElement('span');
      sub.className = 'item-sub';
      sub.textContent = item.subtitle;
      body.append(sub);
    }

    btn.append(icon, body);

    if (item.tag) {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = item.tag;
      btn.append(tag);
    }

    btn.addEventListener('click', () => {
      if (btn.disabled) return;
      // Stop double-clicks while Lua processes the choice.
      list.querySelectorAll('button.item').forEach((b) => { b.disabled = true; });
      post('select', { id: item.id });
    });

    return btn;
  }

  function render(view) {
    titleEl.textContent = view.title || '';
    subtitleEl.textContent = view.subtitle || '';

    badgeEl.textContent = view.badge || '';
    badgeEl.classList.toggle('hidden', !view.badge);

    setIcon(headIcon, view.icon || 'truck');

    canBack = !!view.canBack;
    backBtn.classList.toggle('hidden', !canBack);

    list.replaceChildren();
    const items = view.items || [];
    if (items.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = 'Nothing to show here.';
      list.append(empty);
    } else {
      items.forEach((item) => list.append(makeItem(item)));
    }

    list.scrollTop = 0;
    const first = list.querySelector('button.item:not([disabled])');
    if (first) first.focus({ preventScroll: true });
  }

  function show() { panel.classList.remove('hidden'); }

  function hide() {
    panel.classList.add('hidden');
    list.replaceChildren();
    canBack = false;
  }

  function moveFocus(step) {
    const items = [...list.querySelectorAll('button.item:not([disabled])')];
    if (items.length === 0) return;
    const current = items.indexOf(document.activeElement);
    let next;
    if (current === -1) next = step > 0 ? 0 : items.length - 1;
    else next = (current + step + items.length) % items.length;
    items[next].focus();
    items[next].scrollIntoView({ block: 'nearest' });
  }

  window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.action === 'open') show();
    else if (data.action === 'close') hide();
    else if (data.action === 'render') { show(); render(data.view || {}); }
    else if (data.action === 'editor-open') edOpen(data);
    else if (data.action === 'editor-close') edHide();
  });

  document.addEventListener('keydown', (event) => {
    if (!editorEl.classList.contains('hidden')) {
      if (event.key === 'Escape') {
        event.preventDefault();
        post('editor:close');
      }
      return;
    }
    if (panel.classList.contains('hidden')) return;
    switch (event.key) {
      case 'Escape':
        event.preventDefault();
        post('close');
        break;
      case 'Backspace':
        if (canBack) {
          event.preventDefault();
          post('back');
        }
        break;
      case 'ArrowDown':
        event.preventDefault();
        moveFocus(1);
        break;
      case 'ArrowUp':
        event.preventDefault();
        moveFocus(-1);
        break;
    }
  });

  backBtn.addEventListener('click', () => post('back'));
  closeBtn.addEventListener('click', () => post('close'));
  setIcon(backBtn, 'back');
  setIcon(closeBtn, 'close');
  hide();

  // ===================== CONFIGURATOR (/towedit) =====================
  const editorEl = document.getElementById('editor');
  const edBody = document.getElementById('edBody');
  const edTitle = document.getElementById('editorTitle');
  const edSub = document.getElementById('editorSub');
  const edStatus = document.getElementById('editorStatus');
  const edIcon = document.getElementById('edIcon');
  const edReset = document.getElementById('edReset');
  const edSave = document.getElementById('edSave');
  const edCancel = document.getElementById('edCancel');
  const edClose = document.getElementById('edClose');

  const PRESET_OPTIONS = [
    ['flatbed', 'Flatbed'],
    ['wheel_lift', 'Wheel-lift (hook)'],
    ['trailer', 'Transport trailer']
  ];
  const STATUS_TEXT = { new: 'NEW', builtin: 'BUILT-IN', modified: 'MODIFIED', custom: 'CUSTOM' };
  const MAX_SLOTS = 8;

  let draft = null;
  let stepSize = 0.05;
  let resetArmed = false;
  let resetLabel = null;
  let sendTimer = null;

  const round3 = (n) => Math.round(n * 1000) / 1000;

  // Small DOM helper. Text is always set with textContent, never as HTML.
  function el(tag, props, children) {
    const node = document.createElement(tag);
    Object.entries(props || {}).forEach(([key, value]) => {
      if (value === undefined || value === null || value === false) return;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key === 'value') node.value = value;
      else if (key === 'disabled') node.disabled = true;
      else if (key === 'onclick') node.addEventListener('click', value);
      else if (key === 'oninput') node.addEventListener('input', value);
      else if (key === 'onchange') node.addEventListener('change', value);
      else node.setAttribute(key, value === true ? '' : String(value));
    });
    (children || []).forEach((child) => node.append(child));
    return node;
  }

  // Changes are sent to Lua shortly after each edit, so the 3D markers follow the form.
  function sendDraft() {
    clearTimeout(sendTimer);
    sendTimer = setTimeout(() => post('editor:draft', draft), 60);
  }

  function segmented(options, current, onPick) {
    return el('div', { class: 'seg', role: 'group' }, options.map(([value, text]) =>
      el('button', {
        type: 'button',
        class: 'seg-btn' + (value === current ? ' on' : ''),
        'aria-pressed': value === current ? 'true' : 'false',
        text,
        onclick: () => onPick(value)
      })
    ));
  }

  function field(label, control) {
    return el('div', { class: 'field' }, [el('span', { text: label }), control]);
  }

  function section(title, children) {
    return el('section', { class: 'ed-sec' }, [el('h2', { text: title }), ...children]);
  }

  // One numeric axis with a text box and +/- nudge buttons that move by the chosen step.
  function axis(name, values, index) {
    const input = el('input', {
      type: 'number',
      step: 'any',
      inputmode: 'decimal',
      value: String(round3(values[index])),
      'aria-label': name
    });
    const apply = (next) => {
      values[index] = round3(next);
      input.value = String(values[index]);
      sendDraft();
    };
    input.addEventListener('input', () => {
      const parsed = parseFloat(input.value);
      if (Number.isFinite(parsed)) {
        values[index] = round3(parsed);
        sendDraft();
      }
    });
    input.addEventListener('blur', () => { input.value = String(round3(values[index])); });
    return el('div', { class: 'axis' }, [
      el('span', { class: 'axis-label', text: name }),
      el('div', { class: 'axis-ctl' }, [
        el('button', { type: 'button', class: 'nudge', text: '−', 'aria-label': 'Decrease ' + name, onclick: () => apply(values[index] - stepSize) }),
        input,
        el('button', { type: 'button', class: 'nudge', text: '+', 'aria-label': 'Increase ' + name, onclick: () => apply(values[index] + stepSize) })
      ])
    ]);
  }

  function vector(title, values) {
    return el('div', { class: 'vec' }, [
      el('div', { class: 'vec-title', text: title }),
      el('div', { class: 'vec-row' }, [axis('X', values, 0), axis('Y', values, 1), axis('Z', values, 2)])
    ]);
  }

  function slotCard(slot, index) {
    const nameInput = el('input', {
      type: 'text',
      maxlength: '32',
      value: slot.label || '',
      'aria-label': 'Loading spot name',
      oninput: (event) => { slot.label = event.target.value; sendDraft(); }
    });
    const remove = el('button', {
      type: 'button',
      class: 'mini danger',
      text: 'Remove',
      disabled: draft.slots.length <= 1,
      onclick: () => { draft.slots.splice(index, 1); renderForm(); sendDraft(); }
    });
    const method = el('select', {
      'aria-label': 'Attach method',
      onchange: (event) => { slot.method = event.target.value; sendDraft(); }
    }, [
      el('option', { value: 'entity', text: 'Standard attach' }),
      el('option', { value: 'native_trailer', text: 'Native trailer hitch' })
    ]);
    method.value = slot.method || 'entity';

    return el('div', { class: 'slot' }, [
      el('div', { class: 'slot-head' }, [el('span', { class: 'slot-num', text: '#' + (index + 1) }), nameInput, remove]),
      vector('Deck offset (X · Y · Z)', slot.offset),
      el('details', { class: 'adv' }, [
        el('summary', { text: 'Advanced: unload & rotation' }),
        vector('Unload position', slot.unload),
        vector('Rotation', slot.rotation),
        field('Attach method', method)
      ])
    ]);
  }

  function addSlot() {
    if (draft.slots.length >= MAX_SLOTS) return;
    const last = draft.slots[draft.slots.length - 1];
    draft.slots.push({
      label: 'Loading spot ' + (draft.slots.length + 1),
      offset: [last.offset[0], round3(last.offset[1] - 2.5), last.offset[2]],
      rotation: [...last.rotation],
      unload: [...last.unload],
      method: last.method || 'entity'
    });
    renderForm();
    sendDraft();
  }

  function renderForm() {
    const labelInput = el('input', {
      type: 'text',
      maxlength: '48',
      value: draft.label || '',
      'aria-label': 'Display name',
      oninput: (event) => { draft.label = event.target.value; sendDraft(); }
    });
    const preset = el('select', {
      'aria-label': 'Preset',
      onchange: (event) => { draft.preset = event.target.value; sendDraft(); }
    }, PRESET_OPTIONS.map(([value, text]) => el('option', { value, text })));
    preset.value = draft.preset;

    edBody.replaceChildren(
      section('Vehicle', [
        el('div', { class: 'row2' }, [
          field('Model (spawn name)', el('input', { type: 'text', value: draft.model, disabled: true })),
          field('Display name', labelInput)
        ]),
        el('div', { class: 'row2' }, [
          field('Type', segmented([['truck', 'Truck'], ['trailer', 'Trailer']], draft.kind, (value) => {
            draft.kind = value;
            renderForm();
            sendDraft();
          })),
          field('Preset', preset)
        ]),
        el('div', { class: 'row2' }, [
          field('Gate door (0–7, empty = none)', el('input', {
            type: 'number',
            min: '0',
            max: '7',
            step: '1',
            placeholder: 'None',
            value: draft.gate === null || draft.gate === undefined ? '' : String(draft.gate),
            'aria-label': 'Gate door index',
            oninput: (event) => {
              const raw = event.target.value.trim();
              draft.gate = raw === '' ? null : Number(raw);
              sendDraft();
            }
          }))
        ])
      ]),
      section('Nudge step', [
        segmented([[0.01, '0.01'], [0.05, '0.05'], [0.1, '0.1'], [0.5, '0.5']], stepSize, (value) => {
          stepSize = value;
          renderForm();
        })
      ]),
      section('Loading spots', [
        ...draft.slots.map((slot, index) => slotCard(slot, index)),
        el('button', {
          type: 'button',
          class: 'btn ghost wide',
          text: '+ Add loading spot',
          disabled: draft.slots.length >= MAX_SLOTS,
          onclick: addSlot
        })
      ])
    );
  }

  // Makes sure every position is three real numbers before the form uses it.
  const cleanTriple = (value, fallback) => [0, 1, 2].map((i) => {
    const n = Number(value && value[i]);
    return Number.isFinite(n) ? n : fallback[i];
  });

  function edOpen(data) {
    draft = data.draft;
    draft.slots = (draft.slots || []).map((slot) => ({
      label: slot.label || '',
      offset: cleanTriple(slot.offset, [0, 0, 0]),
      unload: cleanTriple(slot.unload, [0, -8, 0.4]),
      rotation: cleanTriple(slot.rotation, [0, 0, 0]),
      method: slot.method || 'entity'
    }));
    draft.label = draft.label || draft.model;

    resetLabel = data.resetLabel || null;
    resetArmed = false;
    edReset.textContent = resetLabel || '';
    edReset.classList.toggle('hidden', !resetLabel);

    edTitle.textContent = draft.label;
    edSub.textContent = draft.model + (data.vehicleName ? ' · ' + data.vehicleName : '');
    edStatus.textContent = STATUS_TEXT[data.status] || '';
    setIcon(edIcon, draft.kind === 'trailer' ? 'trailer' : 'truck');

    renderForm();
    panel.classList.add('hidden');
    editorEl.classList.remove('hidden');
  }

  function edHide() {
    editorEl.classList.add('hidden');
    edBody.replaceChildren();
    draft = null;
  }

  edSave.addEventListener('click', () => {
    if (!draft) return;
    clearTimeout(sendTimer);
    post('editor:save', draft);
  });

  edReset.addEventListener('click', () => {
    if (!draft) return;
    // Two clicks, because there is no confirm dialog inside the game overlay.
    if (!resetArmed) {
      resetArmed = true;
      edReset.textContent = 'Click again to confirm';
      return;
    }
    post('editor:reset', { model: draft.model });
  });

  edCancel.addEventListener('click', () => post('editor:close'));
  edClose.addEventListener('click', () => post('editor:close'));
  setIcon(edClose, 'close');
})();

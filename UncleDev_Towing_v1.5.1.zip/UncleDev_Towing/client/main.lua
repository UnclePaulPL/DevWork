local busy = false
local activeBlip

local function note(message, level)
  lib.notify({ title = 'UncleDev Towing', description = message, type = level or 'inform' })
end
RegisterNetEvent('uncledev_tow:notify', note)

local function carrierConfig(vehicle)
  if vehicle == 0 or not DoesEntityExist(vehicle) then return nil end
  return Config.CarrierForModel(GetEntityModel(vehicle))
end

local function vehicleName(vehicle)
  local model = GetEntityModel(vehicle)
  local display = GetDisplayNameFromVehicleModel(model)
  local name = (display and display ~= 'CARNOTFOUND' and GetLabelText(display)) or ''
  if name == '' or name == 'NULL' then name = GetEntityArchetypeName(vehicle) end
  return name or 'Vehicle'
end

local function nearbyCarriers()
  local ped = PlayerPedId()
  local center = GetEntityCoords(ped)
  local result = {}
  for _, vehicle in ipairs(GetGamePool('CVehicle')) do
    local cfg = carrierConfig(vehicle)
    if cfg then
      local dist = #(GetEntityCoords(vehicle) - center)
      if dist <= Config.InteractionDistance then
        result[#result + 1] = { vehicle = vehicle, cfg = cfg, distance = dist }
      end
    end
  end
  table.sort(result, function(a, b) return a.distance < b.distance end)
  return result
end

local function nearbyCargo(carrier, slot)
  local cfg = carrierConfig(carrier)
  if not cfg or not cfg.slots[slot] then return {} end
  local offset = cfg.slots[slot].offset
  local center = GetOffsetFromEntityInWorldCoords(carrier, offset[1], offset[2], offset[3])
  local choices = {}
  for _, vehicle in ipairs(GetGamePool('CVehicle')) do
    if vehicle ~= carrier and not carrierConfig(vehicle)
       and not IsEntityAttached(vehicle)
       and not Config.BlockedVehicleClasses[GetVehicleClass(vehicle)]
       and (Entity(vehicle).state.uncledevTowCarrier or 0) == 0 then
      local distance = #(GetEntityCoords(vehicle) - center)
      if distance <= Config.MaxAttachDistance and #(GetEntityCoords(vehicle) - GetEntityCoords(carrier)) <= Config.MaxAttachDistance then
        choices[#choices + 1] = { vehicle = vehicle, distance = distance }
      end
    end
  end
  table.sort(choices, function(a, b) return a.distance < b.distance end)
  return choices
end

local function networkControl(entity, timeout)
  local deadline = GetGameTimer() + (timeout or 2500)
  while DoesEntityExist(entity) and not NetworkHasControlOfEntity(entity) and GetGameTimer() < deadline do
    NetworkRequestControlOfEntity(entity)
    Wait(60)
  end
  return DoesEntityExist(entity) and NetworkHasControlOfEntity(entity)
end

-- Gate / ramp on rollback trucks. The gate is a GTA vehicle door (index set with Config.SetGate).
-- The network owner of the truck changes it, so we take control first.
local function gateOpen(carrier, door)
  if not door or not DoesEntityExist(carrier) or not networkControl(carrier, 1500) then return end
  SetVehicleDoorOpen(carrier, door, false, false)
  local deadline = GetGameTimer() + 2500
  while DoesEntityExist(carrier) and GetVehicleDoorAngleRatio(carrier, door) < 0.95 and GetGameTimer() < deadline do
    Wait(50)
  end
end

local function gateShut(carrier, door)
  if not door or not DoesEntityExist(carrier) or not networkControl(carrier, 1500) then return end
  SetVehicleDoorShut(carrier, door, false)
end

-- Slides an attached vehicle along the deck from one offset/rotation to another.
-- Used for winch-in (pull up the deck) and for winch-out / rollback (slide off the back).
-- Returns false if either entity disappears mid-slide.
local function slideOnDeck(carrier, vehicle, fromOff, toOff, fromRot, toRot, duration, easing)
  local started = GetGameTimer()
  local function lerp(a, b, e) return a + (b - a) * e end
  while true do
    if not DoesEntityExist(vehicle) or not DoesEntityExist(carrier) then return false end
    local t = math.min((GetGameTimer() - started) / duration, 1.0)
    local e = easing == 'accel' and t * t or (t * t * (3.0 - 2.0 * t))
    AttachEntityToEntity(vehicle, carrier, 0,
      lerp(fromOff[1], toOff[1], e), lerp(fromOff[2], toOff[2], e), lerp(fromOff[3], toOff[3], e),
      lerp(fromRot[1], toRot[1], e), lerp(fromRot[2], toRot[2], e), lerp(fromRot[3], toRot[3], e),
      false, false, false, false, 2, true)
    if t >= 1.0 then return true end
    Wait(0)
  end
end

local function attach(carrierNet, cargoNet, slotNum, winch)
  local carrier, vehicle = NetToVeh(carrierNet), NetToVeh(cargoNet)
  if carrier == 0 or vehicle == 0 or not DoesEntityExist(vehicle) then return false end
  local cfg = carrierConfig(carrier)
  local slot = cfg and cfg.slots[slotNum]
  if not slot or not NetworkHasControlOfEntity(vehicle) then return false end
  if IsEntityAttachedToEntity(vehicle, carrier) then return true end

  -- Winching in: open the gate first, then close it once the vehicle is on the deck.
  local gate = winch and cfg.gate or nil
  if gate then gateOpen(carrier, gate) end

  local off, rot = slot.offset, slot.rotation
  SetVehicleEngineOn(vehicle, false, true, true)
  SetVehicleHandbrake(vehicle, true)
  SetEntityCollision(vehicle, false, false)
  if slot.method == 'native_trailer' then
    -- Native trailer attach for compatible GTA carrier trailers (opt-in per slot).
    AttachVehicleOnToTrailer(vehicle, carrier, 0.0, 0.0, 0.0, off[1], off[2], off[3], rot[1], rot[2], rot[3], true)
  else
    if winch then
      -- Pull the vehicle up from wherever it is, so it never teleports onto the deck.
      local start = GetOffsetFromEntityGivenWorldCoords(carrier, GetEntityCoords(vehicle))
      local cr, vr = GetEntityRotation(carrier, 2), GetEntityRotation(vehicle, 2)
      local yaw = (vr.z - cr.z + 540.0) % 360.0 - 180.0
      slideOnDeck(carrier, vehicle, { start.x, start.y, start.z }, off,
        { vr.x - cr.x, vr.y - cr.y, yaw }, rot, Config.WinchLoadDuration, 'smooth')
    end
    -- Generic attachment is ideal for add-on trucks, flatbeds and custom trailers.
    AttachEntityToEntity(vehicle, carrier, 0, off[1], off[2], off[3], rot[1], rot[2], rot[3], false, false, false, false, 2, true)
  end
  if gate then gateShut(carrier, gate) end
  return IsEntityAttachedToEntity(vehicle, carrier)
end

RegisterNetEvent('uncledev_tow:attach', function(carrierNet, cargoNet, slot, style)
  CreateThread(function()
    for attempt = 1, 18 do
      local vehicle = NetToVeh(cargoNet)
      if vehicle ~= 0 and DoesEntityExist(vehicle) then
        if not NetworkHasControlOfEntity(vehicle) then networkControl(vehicle, 600) end
        if attach(carrierNet, cargoNet, slot, style == 'winch') then return end
      end
      Wait(180)
    end
    note('Tow registered, but attachment failed. Check vehicle networking and offsets.', 'error')
  end)
end)

local function detachControlled(carrierNet, cargoNet, slotNum)
  local vehicle = NetToVeh(cargoNet)
  if vehicle == 0 or not DoesEntityExist(vehicle) or not NetworkHasControlOfEntity(vehicle) then return end
  local carrier = NetToVeh(carrierNet)
  if IsEntityAttached(vehicle) then DetachEntity(vehicle, true, true) end
  SetEntityCollision(vehicle, true, true)
  SetVehicleHandbrake(vehicle, false)
  if carrier ~= 0 and DoesEntityExist(carrier) then
    local cfg = carrierConfig(carrier)
    local slot = cfg and cfg.slots[slotNum]
    local v = slot and slot.unload or { 0.0, -8.0, 0.4 }
    local drop = GetOffsetFromEntityInWorldCoords(carrier, v[1], v[2], v[3])
    SetEntityCoordsNoOffset(vehicle, drop.x, drop.y, drop.z, false, false, false)
  end
  SetVehicleOnGroundProperly(vehicle)
end

RegisterNetEvent('uncledev_tow:detach', function(carrierNet, cargoNet, slot)
  -- The CURRENT NETWORK OWNER handles the physics; peers do not fight for control.
  detachControlled(carrierNet, cargoNet, slot)
end)

local function operate(carrier, cargo, slot, action, style)
  if busy then return end
  if not DoesEntityExist(carrier) then return note('Truck/trailer no longer exists.', 'error') end
  if IsPedInAnyVehicle(PlayerPedId(), false) then return note('Exit your vehicle to operate the tow system.', 'error') end
  busy = true
  local label = action == 'load' and 'Winching vehicle in...'
    or action == 'unload' and (style == 'rollback' and 'Rolling back...' or 'Winching vehicle out...')
    or 'Processing impound...'
  local duration = action == 'load' and Config.LoadDuration or action == 'unload' and Config.UnloadDuration or 4500
  local success = lib.progressCircle({
    duration = duration, label = label, position = 'bottom', canCancel = true,
    disable = { move = true, car = true, combat = true },
    anim = { dict = 'mini@repair', clip = 'fixing_a_ped' }
  })
  if not success then busy = false return end
  if not DoesEntityExist(carrier) then busy = false return note('Carrier is no longer available.', 'error') end

  local carrierNet = NetworkGetNetworkIdFromEntity(carrier)
  local ok, message
  if action == 'load' then
    if not DoesEntityExist(cargo) or not networkControl(cargo, 2600) then
      busy = false
      return note('Cannot control target vehicle. Try again near its owner.', 'error')
    end
    ok, message = lib.callback.await('uncledev_tow:load', false, carrierNet, NetworkGetNetworkIdFromEntity(cargo), slot, 'winch')
  elseif action == 'unload' then
    local cfg = carrierConfig(carrier)
    local spot = cfg and cfg.slots[slot]
    local gate = cfg and cfg.gate or nil
    -- Gate drops before the vehicle slides off, for both winch-out and rollback.
    if gate then gateOpen(carrier, gate) end
    local rot = spot and spot.rotation
    local rollback = style == 'rollback'
    local tilt = (rollback and rot) and { rot[1] + Config.RollbackTilt, rot[2], rot[3] } or rot
    local moved = false
    if spot and DoesEntityExist(cargo) and IsEntityAttachedToEntity(cargo, carrier) and networkControl(cargo, 1500) then
      -- Animate first. If the server refuses the unload, the vehicle slides back onto its spot.
      slideOnDeck(carrier, cargo, spot.offset, spot.unload, rot, tilt,
        rollback and Config.RollbackDuration or Config.WinchOutDuration,
        rollback and 'accel' or 'smooth')
      moved = true
    end
    ok, message = lib.callback.await('uncledev_tow:unload', false, carrierNet, slot)
    if moved and not ok and DoesEntityExist(cargo) then
      slideOnDeck(carrier, cargo, spot.unload, spot.offset, tilt, rot, 800, 'smooth')
    end
    if gate then gateShut(carrier, gate) end
  else
    ok, message = lib.callback.await('uncledev_tow:impound', false, carrierNet, slot)
  end
  note(message or (ok and 'Tow operation completed.' or 'Tow operation failed.'), ok and 'success' or 'error')
  busy = false
end

-- ============================================================
-- NUI PANEL
-- Lua decides what every screen contains and what each button does.
-- The browser side (html/) only renders the list and reports the clicked id.
-- ============================================================
local ui = { open = false, current = nil, stack = {}, handlers = {} }

local function render(view)
  ui.current = view
  ui.handlers = {}
  local items = {}
  for i, item in ipairs(view.items or {}) do
    local id = ('item%d'):format(i)
    ui.handlers[id] = item.onSelect
    items[i] = {
      id = id,
      title = item.title,
      subtitle = item.subtitle,
      icon = item.icon,
      tone = item.tone,
      tag = item.tag,
      disabled = item.disabled == true
    }
  end
  SendNUIMessage({
    action = 'render',
    view = {
      title = view.title,
      subtitle = view.subtitle,
      badge = view.badge,
      icon = view.icon,
      canBack = #ui.stack > 0,
      items = items
    }
  })
end

local function openPanel(view)
  ui.open = true
  ui.stack = {}
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'open' })
  render(view)
end

local function closePanel()
  if not ui.open then return end
  ui.open, ui.stack, ui.handlers, ui.current = false, {}, {}, nil
  SetNuiFocus(false, false)
  SendNUIMessage({ action = 'close' })
end

local function goTo(view)
  if ui.current then ui.stack[#ui.stack + 1] = ui.current end
  render(view)
end

local function goBack()
  local previous = table.remove(ui.stack)
  if previous then render(previous) end
end

RegisterNUICallback('select', function(data, cb)
  cb('ok')
  local handler = ui.handlers[data and data.id or '']
  if handler then CreateThread(handler) end
end)

RegisterNUICallback('back', function(_, cb)
  cb('ok')
  CreateThread(goBack)
end)

RegisterNUICallback('close', function(_, cb)
  cb('ok')
  CreateThread(closePanel)
end)

local function cargoName(net)
  local vehicle = NetToVeh(net)
  if vehicle == 0 or not DoesEntityExist(vehicle) then return 'Vehicle (syncing...)' end
  return vehicleName(vehicle)
end

local function loadedCount(state, total)
  local count = 0
  for i = 1, total do
    local net = state[i] or state[tostring(i)]
    if net and net ~= 0 then count = count + 1 end
  end
  return count
end

-- Screen: pick a nearby vehicle to put into an empty loading spot.
local function pickView(carrier, cfg, slotNumber)
  local slot = cfg.slots[slotNumber]
  local choices = nearbyCargo(carrier, slotNumber)
  local items = {}
  for i = 1, math.min(#choices, 12) do
    local vehicle, distance = choices[i].vehicle, choices[i].distance
    items[#items + 1] = {
      title = vehicleName(vehicle),
      subtitle = ('Plate %s  •  %.1f m away'):format(GetVehicleNumberPlateText(vehicle), distance),
      icon = 'car',
      tone = 'ok',
      tag = 'WINCH IN',
      onSelect = function()
        closePanel()
        operate(carrier, vehicle, slotNumber, 'load')
      end
    }
  end
  if #items == 0 then
    items[1] = {
      title = 'No vehicles in range',
      subtitle = 'Park a vehicle closer to this loading spot',
      icon = 'alert',
      disabled = true
    }
  end
  return {
    title = 'Winch in: ' .. slot.label,
    subtitle = cfg.label,
    badge = ('%d found'):format(#choices),
    icon = 'winch',
    items = items
  }
end

-- Screen: a loaded spot. Winch out, rollback, or impound the vehicle in it.
local function slotView(carrier, cfg, slotNumber, cargoNet)
  local slot = cfg.slots[slotNumber]
  local cargo = NetToVeh(cargoNet)
  return {
    title = slot.label,
    subtitle = cargoName(cargoNet),
    badge = 'LOADED',
    icon = 'car',
    items = {
      {
        title = 'Winch out',
        subtitle = 'Controlled lowering off the back',
        icon = 'winch',
        tone = 'ok',
        tag = 'WINCH OUT',
        onSelect = function()
          closePanel()
          operate(carrier, cargo, slotNumber, 'unload', 'winch_out')
        end
      },
      {
        title = 'Rollback',
        subtitle = 'Tilt deck, slide vehicle off',
        icon = 'rollback',
        tone = 'warn',
        tag = 'ROLLBACK',
        onSelect = function()
          closePanel()
          operate(carrier, cargo, slotNumber, 'unload', 'rollback')
        end
      },
      {
        title = 'Impound vehicle',
        subtitle = Config.EnableImpound and 'Must be at an impound lot' or 'Impound is disabled on this server',
        icon = 'impound',
        tone = 'danger',
        tag = 'IMPOUND',
        disabled = not Config.EnableImpound,
        onSelect = function()
          closePanel()
          operate(carrier, nil, slotNumber, 'impound')
        end
      }
    }
  }
end

-- Screen: one truck or trailer, one row per loading spot.
local function carrierView(carrier)
  if not DoesEntityExist(carrier) then
    note('Truck/trailer no longer exists.', 'error')
    return nil
  end
  local cfg = carrierConfig(carrier)
  if not cfg then
    note('This carrier is not configured.', 'error')
    return nil
  end
  local net = NetworkGetNetworkIdFromEntity(carrier)
  local state = lib.callback.await('uncledev_tow:state', false, net) or {}
  local items = {}
  for number, slot in ipairs(cfg.slots) do
    local cargoNet = state[number] or state[tostring(number)]
    if cargoNet and cargoNet ~= 0 then
      items[#items + 1] = {
        title = slot.label,
        subtitle = cargoName(cargoNet),
        icon = 'car',
        tone = 'warn',
        tag = 'LOADED',
        onSelect = function() goTo(slotView(carrier, cfg, number, cargoNet)) end
      }
    else
      items[#items + 1] = {
        title = slot.label,
        subtitle = 'Empty. Select to winch in a nearby vehicle.',
        icon = 'plus',
        tone = 'ok',
        tag = 'EMPTY',
        onSelect = function() goTo(pickView(carrier, cfg, number)) end
      }
    end
  end
  return {
    title = cfg.label,
    subtitle = cfg.kind == 'trailer' and 'Transport trailer' or 'Tow truck',
    badge = ('%d / %d loaded'):format(loadedCount(state, #cfg.slots), #cfg.slots),
    icon = cfg.kind == 'trailer' and 'trailer' or 'truck',
    items = items
  }
end

-- Screen: several trucks/trailers nearby, pick one.
local function carriersView(carriers)
  local items = {}
  for _, item in ipairs(carriers) do
    local carrier, cfg = item.vehicle, item.cfg
    items[#items + 1] = {
      title = cfg.label,
      subtitle = ('%.1f m away  •  %d loading spot(s)'):format(item.distance, #cfg.slots),
      icon = cfg.kind == 'trailer' and 'trailer' or 'truck',
      tone = 'info',
      tag = cfg.kind == 'trailer' and 'TRAILER' or 'TRUCK',
      onSelect = function()
        local view = carrierView(carrier)
        if view then goTo(view) end
      end
    }
  end
  return {
    title = 'Tow Operations',
    subtitle = 'Choose a truck or trailer nearby',
    badge = ('%d nearby'):format(#carriers),
    icon = 'truck',
    items = items
  }
end

local function openMenu()
  if ui.open then return closePanel() end
  if busy then return end
  local carriers = nearbyCarriers()
  if #carriers == 0 then return note('No configured flatbed, tow truck or transport trailer nearby.', 'error') end
  if #carriers == 1 then
    local view = carrierView(carriers[1].vehicle)
    if view then openPanel(view) end
    return
  end
  openPanel(carriersView(carriers))
end

RegisterCommand(Config.Command, openMenu, false)
RegisterKeyMapping(Config.Command, 'Open UncleDev Tow Operations', 'keyboard', Config.Keybind)

-- Quick helper: identifies the REAL spawn name, including add-on vehicles.
RegisterCommand('towmodel', function()
  local ped = PlayerPedId()
  local vehicle = GetVehiclePedIsIn(ped, false)
  if vehicle == 0 then
    local pool = GetGamePool('CVehicle')
    local pos, distance = GetEntityCoords(ped), 12.0
    for _, entity in ipairs(pool) do
      local d = #(GetEntityCoords(entity) - pos)
      if d < distance then vehicle, distance = entity, d end
    end
  end
  if vehicle == 0 then return note('No vehicle within 12m.', 'error') end
  local name = GetEntityArchetypeName(vehicle)
  local cfg = carrierConfig(vehicle)
  note(('Spawn name: %s | %s'):format(name, cfg and 'Registered carrier' or 'Not registered'))
  print(('[UncleDev Towing] Vehicle model: %s | hash: %s'):format(name, GetEntityModel(vehicle)))
end, false)

RegisterCommand(Config.DispatchCommand, function(_, args)
  if not Config.UseDispatch then return end
  local message = table.concat(args, ' ')
  if message == '' then message = 'Tow assistance requested' end
  TriggerServerEvent('uncledev_tow:request', message)
end, false)

RegisterNetEvent('uncledev_tow:dispatch', function(src, name, message, coords)
  note(('Tow request from %s (#%d): %s'):format(name, src, message))
  if activeBlip then RemoveBlip(activeBlip) end
  activeBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
  SetBlipSprite(activeBlip, 68)
  SetBlipColour(activeBlip, 5)
  SetBlipScale(activeBlip, 0.9)
  SetBlipRoute(activeBlip, true)
  BeginTextCommandSetBlipName('STRING')
  AddTextComponentString('Tow Request: ' .. name)
  EndTextCommandSetBlipName(activeBlip)
  local blip = activeBlip
  SetTimeout(Config.DispatchBlipDuration * 1000, function()
    if activeBlip == blip then RemoveBlip(activeBlip) activeBlip = nil end
  end)
end)

-- Repair after streaming or network ownership migration, using server-owned state bags.
CreateThread(function()
  while true do
    Wait(3000)
    for _, vehicle in ipairs(GetGamePool('CVehicle')) do
      if NetworkHasControlOfEntity(vehicle) then
        local carrierNet = Entity(vehicle).state.uncledevTowCarrier
        local slot = Entity(vehicle).state.uncledevTowSlot
        if type(carrierNet) == 'number' and carrierNet > 0 and type(slot) == 'number' and slot > 0 then
          local carrier = NetToVeh(carrierNet)
          if carrier ~= 0 and not IsEntityAttachedToEntity(vehicle, carrier) then
            attach(carrierNet, NetworkGetNetworkIdFromEntity(vehicle), slot)
          end
        end
      end
    end
  end
end)

CreateThread(function()
  if not Config.ShowMarkers or not Config.EnableImpound then return end
  while true do
    local sleep = 1500
    local coords = GetEntityCoords(PlayerPedId())
    for _, point in ipairs(Config.ImpoundLocations) do
      if #(coords - point.coords) < 40.0 then
        sleep = 0
        DrawMarker(1, point.coords.x, point.coords.y, point.coords.z - 1.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          2.2, 2.2, 0.4, 255, 175, 45, 95, false, false, 2, false, nil, nil, false)
      end
    end
    Wait(sleep)
  end
end)

-- ============================================================
-- IN-GAME CONFIGURATOR (/towedit)
-- Staff stand next to a truck or trailer, run /towedit, and set its loading spots.
-- Coloured markers show each spot live while editing.
-- ============================================================
RegisterNetEvent('uncledev_tow:registry', function(list)
  Config.Overrides = type(list) == 'table' and list or {}
  Config.RebuildCarriers()
end)

CreateThread(function()
  while not NetworkIsSessionStarted() do Wait(500) end
  TriggerServerEvent('uncledev_tow:requestRegistry')
end)

local editor = { open = false, vehicle = 0, draft = nil }

local function nearestVehicle(maxDistance)
  local ped = PlayerPedId()
  local current = GetVehiclePedIsIn(ped, false)
  if current ~= 0 then return current end
  local pos, best, bestDistance = GetEntityCoords(ped), 0, maxDistance
  for _, entity in ipairs(GetGamePool('CVehicle')) do
    local d = #(GetEntityCoords(entity) - pos)
    if d < bestDistance then best, bestDistance = entity, d end
  end
  return best
end

local function hasOverride(model)
  for _, entry in ipairs(Config.Overrides) do
    if entry.model == model then return true end
  end
  return false
end

local function copyTriple(t) return { t[1], t[2], t[3] } end

-- Builds the editor's draft from the vehicle's current settings, or a starting point for a new one.
local function draftFor(vehicle)
  local model = GetEntityArchetypeName(vehicle):lower()
  local existing = Config.CarrierForModel(GetEntityModel(vehicle))
  local builtin = Config.BuiltinTrucks[model] ~= nil or Config.BuiltinTrailers[model] ~= nil
  local override = hasOverride(model)
  local status = 'new'
  if override and builtin then status = 'modified'
  elseif override then status = 'custom'
  elseif builtin then status = 'builtin' end

  local draft
  if existing then
    local slots = {}
    for i, slot in ipairs(existing.slots) do
      slots[i] = {
        label = slot.label,
        offset = copyTriple(slot.offset),
        rotation = copyTriple(slot.rotation),
        unload = copyTriple(slot.unload),
        method = slot.method
      }
    end
    draft = { model = model, kind = existing.kind, preset = existing.preset, label = existing.label, slots = slots, gate = existing.gate }
  else
    local preset = Config.Presets.flatbed
    draft = {
      model = model, kind = 'truck', preset = 'flatbed', label = vehicleName(vehicle),
      slots = {{
        label = 'Main deck',
        offset = { 0.0, -2.7, 1.0 },
        rotation = copyTriple(preset.rotation),
        unload = copyTriple(preset.unload),
        method = 'entity'
      }}
    }
  end
  return draft, status
end

local function closeEditor()
  if not editor.open then return end
  editor.open, editor.vehicle, editor.draft = false, 0, nil
  SetNuiFocus(false, false)
  SendNUIMessage({ action = 'editor-close' })
end

local function openEditor(vehicle)
  local draft, status = draftFor(vehicle)
  editor.open, editor.vehicle, editor.draft = true, vehicle, draft
  SetNuiFocus(true, true)
  SendNUIMessage({
    action = 'editor-open',
    draft = draft,
    status = status,
    vehicleName = vehicleName(vehicle),
    resetLabel = (status == 'modified' and 'Reset to built-in') or (status == 'custom' and 'Delete') or nil
  })
end

-- Live preview: each loading spot (amber) and its unload point (blue) drawn on the vehicle.
CreateThread(function()
  while true do
    if editor.open and editor.draft and DoesEntityExist(editor.vehicle) then
      for _, slot in ipairs(editor.draft.slots or {}) do
        if type(slot.offset) == 'table' and type(slot.unload) == 'table' then
          local o, u = slot.offset, slot.unload
          local p = GetOffsetFromEntityInWorldCoords(editor.vehicle, tonumber(o[1]) or 0.0, tonumber(o[2]) or 0.0, tonumber(o[3]) or 0.0)
          DrawMarker(28, p.x, p.y, p.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 175, 45, 200, false, false, 2, false, nil, nil, false)
          local q = GetOffsetFromEntityInWorldCoords(editor.vehicle, tonumber(u[1]) or 0.0, tonumber(u[2]) or 0.0, tonumber(u[3]) or 0.0)
          DrawMarker(28, q.x, q.y, q.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 60, 200, 255, 200, false, false, 2, false, nil, nil, false)
        end
      end
      Wait(0)
    else
      Wait(500)
    end
  end
end)

RegisterNUICallback('editor:draft', function(data, cb)
  cb('ok')
  if editor.open and type(data) == 'table' then editor.draft = data end
end)

RegisterNUICallback('editor:save', function(data, cb)
  cb('ok')
  CreateThread(function()
    local ok, message = lib.callback.await('uncledev_tow:editor:save', false, data)
    note(message or (ok and 'Saved.' or 'Save failed.'), ok and 'success' or 'error')
    if ok then closeEditor() end
  end)
end)

RegisterNUICallback('editor:reset', function(_, cb)
  cb('ok')
  CreateThread(function()
    local model = editor.draft and editor.draft.model
    if not model then return end
    local ok, message = lib.callback.await('uncledev_tow:editor:reset', false, model)
    note(message or (ok and 'Settings reset.' or 'Reset failed.'), ok and 'success' or 'error')
    if ok then closeEditor() end
  end)
end)

RegisterNUICallback('editor:close', function(_, cb)
  cb('ok')
  CreateThread(closeEditor)
end)

RegisterCommand(Config.EditorCommand, function()
  if editor.open then return closeEditor() end
  if not lib.callback.await('uncledev_tow:editor:check', false) then
    return note('You do not have permission to configure towing.', 'error')
  end
  local vehicle = nearestVehicle(12.0)
  if vehicle == 0 then return note('Stand next to the truck or trailer you want to configure.', 'error') end
  if ui.open then closePanel() end
  openEditor(vehicle)
end, false)

AddEventHandler('onClientResourceStop', function(resource)
  if resource ~= GetCurrentResourceName() then return end
  if ui.open or editor.open then SetNuiFocus(false, false) end
  for _, vehicle in ipairs(GetGamePool('CVehicle')) do
    if NetworkHasControlOfEntity(vehicle) then
      local carrierNet = Entity(vehicle).state.uncledevTowCarrier
      local parent = IsEntityAttached(vehicle) and GetEntityAttachedTo(vehicle) or 0
      if (type(carrierNet) == 'number' and carrierNet > 0) or (parent ~= 0 and carrierConfig(parent)) then
        if IsEntityAttached(vehicle) then DetachEntity(vehicle, true, true) end
        SetEntityCollision(vehicle, true, true)
        SetVehicleHandbrake(vehicle, false)
      end
    end
  end
end)

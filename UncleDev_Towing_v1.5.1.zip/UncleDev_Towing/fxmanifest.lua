fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'UncleDev'
description 'Tow trucks, flatbeds and configurable multi-slot vehicle transport trailers'
version '1.5.1'
shared_scripts {
  '@ox_lib/init.lua',
  'shared/config.lua',
  'shared/vehicles.lua',
  'shared/registry.lua'
}
client_scripts {'client/main.lua'}
server_scripts {'server/main.lua'}
ui_page 'html/index.html'
files {
  'html/index.html',
  'html/style.css',
  'html/app.js'
}
dependency 'ox_lib'

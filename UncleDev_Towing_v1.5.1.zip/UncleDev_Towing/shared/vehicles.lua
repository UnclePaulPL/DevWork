--[[
  UNCLEDEV TOWING | EASY VEHICLE REGISTRY
  This is the ONLY FILE you need to edit to add trucks and car-hauling trailers.

  ADD A FLATBED TRUCK:
  Config.AddTruck('myflatbed', 'flatbed', { 0.0, -2.7, 1.0 }, 'My Flatbed')

  ADD A WHEEL-LIFT TOW TRUCK:
  Config.AddTruck('mytowtruck', 'wheel_lift', { 0.0, -3.8, 0.2 }, 'My Tow Truck')

  ADD A CAR-HAULER TRAILER:
  Config.AddTrailer('mytrailer', 'trailer', { 0.0, -2.0, 1.1 }, 'My Trailer')

  The first name is the VEHICLE SPAWN NAME, not the display name.
  The {x, y, z} values are LEFT/RIGHT, FORWARD/BACK, UP/DOWN.
  Negative y moves toward the back of the truck/trailer.
  Every custom vehicle has different geometry; tune offsets in game.

  Supported presets: 'flatbed', 'wheel_lift', 'trailer'.
  Attach method can be 'entity' (default) or 'native_trailer' (GTA trailer native).
  'native_trailer' works on compatible trailers but can require model-specific tuning.
]]

Config.Trucks = {}
Config.Trailers = {}

Config.Presets = {
  flatbed ={ rotation = { 0.0, 0.0, 0.0 }, unload = { 0.0, -8.0, 0.4 }, method = 'entity' },
  wheel_lift = { rotation = { 0.0, 0.0, 0.0 }, unload = { 0.0, -8.0, 0.4 }, method = 'entity' },
  trailer = { rotation = { 0.0, 0.0, 0.0 }, unload = { 0.0, -9.0, 0.4 }, method = 'entity' },
  rollback = { rotation = { 0.0, 0.0, 0.0 }, unload = { 0.0, -9.0, 0.4 }, method = 'entity' }
}
local presets = Config.Presets

-- GATE / RAMP: if a truck has a moving gate, tell the script which GTA door index it is (0-7).
-- The gate opens before winching in or rolling back and closes afterwards.
-- Find the index in the truck's vehicles.meta (the door bone order). Example:
-- Config.AddTruck('myrollback', 'rollback', { 0.0, -3.0, 1.0 }, 'My Rollback Truck')
-- Config.SetGate('myrollback', 5)
function Config.SetGate(model, door)
  local name = tostring(model):lower()
  local carrier = Config.Trucks[name] or Config.Trailers[name]
  assert(carrier, 'Cannot set a gate for unregistered tow carrier ' .. name)
  assert(math.type(door) == 'integer' and door >= 0 and door <= 7, 'Gate door must be an integer from 0 to 7')
  carrier.gate = door
end

local function vec(t, label)
  assert(type(t) == 'table' and tonumber(t[1]) and tonumber(t[2]) and tonumber(t[3]),
    ('UncleDev Tow: %s needs {x, y, z}'):format(label))
  return { tonumber(t[1]), tonumber(t[2]), tonumber(t[3]) }
end

local function add(store, kind, model, preset, offset, label)
  assert(type(model) == 'string' and model ~= '', 'Tow model spawn name must be a nonempty string')
  local name = model:lower()
  local settings = assert(presets[preset], 'Unknown towing preset: ' .. tostring(preset))
  assert(not Config.Trucks[name] and not Config.Trailers[name], 'Duplicate truck/trailer model: ' .. name)
  store[name] = {
    label = label or model,
    kind = kind,
    preset = preset,
    slots = {{
      label = 'Main deck / hook',
      offset = vec(offset, 'offset'),
      rotation = vec(settings.rotation, 'rotation'),
      unload = vec(settings.unload, 'unload'),
      method = settings.method
    }}
  }
end

function Config.AddTruck(model, preset, offset, label)
  add(Config.Trucks, 'truck', model, preset, offset, label)
end

function Config.AddTrailer(model, preset, offset, label)
  add(Config.Trailers, 'trailer', model, preset, offset, label)
end

-- OPTIONAL: trailers/large trucks with 2+ loading spots.
-- Each slot needs a separate offset. A single carrier can only have one vehicle PER SLOT.
-- Example:
-- Config.SetSlots('mybigtrailer', {
--   { label = 'Front Deck', offset = {0.0, 1.8, 1.4} },
--   { label = 'Rear Deck',  offset = {0.0, -3.2, 1.4} }
-- })
function Config.SetSlots(model, slots)
  local name = tostring(model):lower()
  local carrier = Config.Trucks[name] or Config.Trailers[name]
  assert(carrier, 'Cannot set slots for unregistered tow carrier ' .. name)
  assert(type(slots) == 'table' and #slots >= 1 and #slots <= 8, 'Carrier requires 1-8 slots')
  local original = carrier.slots[1]
  local result = {}
  for i, slot in ipairs(slots) do
    result[i] = {
      label = slot.label or ('Loading spot ' .. i),
      offset = vec(slot.offset, 'slot offset'),
      rotation = vec(slot.rotation or original.rotation, 'slot rotation'),
      unload = vec(slot.unload or original.unload, 'slot unload position'),
      method = slot.method or original.method
    }
    assert(result[i].method == 'entity' or result[i].method == 'native_trailer', 'Unsupported attach method')
  end
  carrier.slots = result
end

-- BUILT-IN TRUCKS (safe to edit positions)
Config.AddTruck('flatbed',  'flatbed',    { 0.0, -2.75, 1.03 }, 'Standard Flatbed')
Config.AddTruck('flatbed2', 'flatbed',    { 0.0, -2.75, 1.05 }, 'Flatbed 2 (custom model if installed)')
Config.AddTruck('towtruck', 'wheel_lift', { 0.0, -3.75, 0.18 }, 'Tow Truck')
Config.AddTruck('towtruck2','wheel_lift', { 0.0, -3.45, 0.14 }, 'Small Tow Truck')
Config.AddTruck('slamtruck','flatbed',    { 0.0, -2.50, 0.55 }, 'Slamtruck')

-- C3 RAM WRECKER (from its vehicles.meta). The offset is a starting point, copied from the
-- wheel-lift tow truck above. Tune it in game with /towedit. Its only door listed is the boot
-- (VEH_EXT_BOOT, usually index 5). Only set a gate with Config.SetGate if the boot really is a ramp.
Config.AddTruck('c3ramwrecker', 'wheel_lift', { 0.0, -3.75, 0.18 }, 'C3 Ram Wrecker')

-- BUILT-IN CAR-HAULER TRAILER (real GTA V model; position is a starting point)
Config.AddTrailer('tr2', 'trailer', { 0.0, -2.0, 1.3 }, 'GTA Car Carrier (tr2)')

-- ADD YOUR OWN HERE: remove '--' before a line to enable it.
-- Config.AddTruck('customflatbed', 'flatbed', { 0.0, -2.9, 1.0 }, 'Custom Flatbed')
-- Config.AddTruck('customwrecker', 'wheel_lift', { 0.0, -4.0, 0.2 }, 'Custom Wrecker')
-- Config.AddTrailer('customcarhauler', 'trailer', { 0.0, -2.0, 1.25 }, 'Custom Car Hauler')

-- OPTIONAL: if you want tr2 to carry more than one vehicle, set slots below
-- after editing the positions to match the model:
-- Config.SetSlots('tr2', {
--   { label = 'Front', offset = {0.0,  1.6, 1.5} },
--   { label = 'Rear',  offset = {0.0, -3.1, 1.5} }
-- })

-- Precompute a safe, shared lookup by model hash, not UI/display name.
Config.CarriersByHash = {}
for name, value in pairs(Config.Trucks) do Config.CarriersByHash[joaat(name)] = value end
for name, value in pairs(Config.Trailers) do Config.CarriersByHash[joaat(name)] = value end

function Config.CarrierForModel(modelHash)
  return Config.CarriersByHash[modelHash]
end

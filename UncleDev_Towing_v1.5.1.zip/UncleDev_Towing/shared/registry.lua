-- Runtime carrier registry (shared by client and server).
-- Built-in trucks and trailers come from shared/vehicles.lua. Entries saved in game with /towedit
-- are stored on the server in data/carriers.json and layered on top: they either replace a
-- built-in model or add a new one. Both sides rebuild the same lookup, so they always agree.

local function deepCopy(value)
  if type(value) ~= 'table' then return value end
  local copy = {}
  for key, inner in pairs(value) do copy[key] = deepCopy(inner) end
  return copy
end

-- Snapshot of the built-in registry, taken after vehicles.lua has run.
Config.BuiltinTrucks = deepCopy(Config.Trucks)
Config.BuiltinTrailers = deepCopy(Config.Trailers)
Config.Overrides = Config.Overrides or {}

local function triple(value, what)
  if type(value) ~= 'table' then return nil, what .. ' needs X, Y and Z.' end
  local x, y, z = tonumber(value[1]), tonumber(value[2]), tonumber(value[3])
  if not (x and y and z) then return nil, what .. ' needs three numbers.' end
  for _, n in ipairs({ x, y, z }) do
    if math.abs(n) > 50.0 then return nil, what .. ' values must be between -50 and 50.' end
  end
  return { x, y, z }
end

-- Checks an entry from the editor or from the saved file. Returns the entry in the same shape
-- vehicles.lua builds, or nil and a message explaining what is wrong.
function Config.NormalizeEntry(input)
  if type(input) ~= 'table' then return nil, 'Invalid entry.' end

  local model = type(input.model) == 'string' and input.model:gsub('%s+', ''):lower() or ''
  if model == '' or #model > 40 or not model:match('^[%w_]+$') then
    return nil, 'Model name must be letters, numbers or underscores.'
  end

  local kind = (input.kind == 'truck' and 'truck') or (input.kind == 'trailer' and 'trailer') or nil
  if not kind then return nil, 'Choose truck or trailer.' end

  local preset = type(input.preset) == 'string' and Config.Presets[input.preset] or nil
  if not preset then return nil, 'Choose a preset.' end

  local label = type(input.label) == 'string' and input.label:sub(1, 48) or ''
  if label == '' then label = model end

  if type(input.slots) ~= 'table' or #input.slots < 1 or #input.slots > 8 then
    return nil, 'Use between 1 and 8 loading spots.'
  end

  local slots = {}
  for index, slot in ipairs(input.slots) do
    if type(slot) ~= 'table' then return nil, 'Invalid loading spot.' end
    local prefix = 'Loading spot ' .. index
    local offset, err = triple(slot.offset, prefix .. ' offset')
    if not offset then return nil, err end
    local unload
    unload, err = triple(slot.unload or preset.unload, prefix .. ' unload position')
    if not unload then return nil, err end
    local rotation
    rotation, err = triple(slot.rotation or preset.rotation, prefix .. ' rotation')
    if not rotation then return nil, err end

    local slotLabel = type(slot.label) == 'string' and slot.label:sub(1, 32) or ''
    slots[index] = {
      label = slotLabel ~= '' and slotLabel or prefix,
      offset = offset,
      rotation = rotation,
      unload = unload,
      method = slot.method == 'native_trailer' and 'native_trailer' or 'entity'
    }
  end

  local gate = nil
  if input.gate ~= nil and input.gate ~= '' then
    local door = tonumber(input.gate)
    if not door or door % 1 ~= 0 or door < 0 or door > 7 then
      return nil, 'Gate door must be a whole number from 0 to 7, or left empty.'
    end
    gate = math.tointeger(door)
  end

  return { model = model, kind = kind, preset = input.preset, label = label, slots = slots, gate = gate }
end

-- Rebuilds Config.Trucks, Config.Trailers and the hash lookup from built-ins plus overrides.
function Config.RebuildCarriers()
  local trucks, trailers = deepCopy(Config.BuiltinTrucks), deepCopy(Config.BuiltinTrailers)

  for _, entry in ipairs(Config.Overrides) do
    local normalized = Config.NormalizeEntry(entry)
    if normalized then
      local carrier = {
        label = normalized.label,
        kind = normalized.kind,
        preset = normalized.preset,
        slots = normalized.slots,
        gate = normalized.gate
      }
      trucks[normalized.model] = nil
      trailers[normalized.model] = nil
      if normalized.kind == 'truck' then
        trucks[normalized.model] = carrier
      else
        trailers[normalized.model] = carrier
      end
    end
  end

  Config.Trucks, Config.Trailers = trucks, trailers
  Config.CarriersByHash = {}
  for name, value in pairs(trucks) do Config.CarriersByHash[joaat(name)] = value end
  for name, value in pairs(trailers) do Config.CarriersByHash[joaat(name)] = value end
end

Config.RebuildCarriers()

Config = {}

-- BASIC SETTINGS
Config.Framework = 'auto' -- auto | esx | qb | qbox | standalone
Config.Command = 'tow'
Config.Keybind = 'F6'
Config.RestrictToJobs = false
Config.Jobs = { mechanic = 0, tow = 0, police = 0 }
Config.AcePermission = 'uncledev.tow'
Config.AdminPermission = 'uncledev.tow.admin' -- may use /towedit to configure trucks and trailers in game
Config.EditorCommand = 'towedit'

-- DISTANCES / SAFETY
Config.InteractionDistance = 16.0
Config.MaxAttachDistance = 18.0
Config.MaxTruckSpeed = 2.0 -- metres/sec; stop before operating
Config.AllowOccupiedVehicles = false
Config.LoadDuration = 5500
Config.UnloadDuration = 2200

-- WINCH & ROLLBACK (animation only; GTA can't rotate the bed itself)
Config.WinchLoadDuration = 4000  -- ms to winch a vehicle up the deck
Config.WinchOutDuration = 4000   -- ms for a controlled winch-out off the back
Config.RollbackDuration = 2800   -- ms for the tilt-and-slide rollback
Config.RollbackTilt = -14.0      -- degrees the vehicle pitches nose-down during a rollback
Config.CooldownSeconds = 2
Config.BlockedVehicleClasses = { [14] = true, [15] = true, [16] = true, [21] = true }

-- IMPOUND
Config.EnableImpound = true
Config.ShowMarkers = true
Config.ImpoundReward = 0 -- 0 = off. Database persistence is NOT changed.
Config.ImpoundLocations = {
  { label = 'Davis Impound', coords = vector3(409.2, -1623.2, 29.3), radius = 22.0 },
  { label = 'Sandy Shores Impound', coords = vector3(1723.5, 3692.8, 34.2), radius = 25.0 },
  { label = 'Paleto Impound', coords = vector3(-219.2, 6212.9, 31.5), radius = 30.0 }
}

-- TOW REQUEST DISPATCH
Config.UseDispatch = true
Config.DispatchCommand = 'towrequest'
Config.DispatchBlipDuration = 180
Config.DispatchJobsOnly = true

-- EDIT ONLY shared/vehicles.lua TO ADD TRUCKS OR TRAILERS.
Config.Debug = false

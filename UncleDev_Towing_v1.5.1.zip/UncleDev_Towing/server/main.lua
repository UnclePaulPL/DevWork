local loads = {}      -- [carrierNet] = {[slotNumber] = cargoNet}
local reverse = {}    -- [cargoNet] = {carrierNet = x, slot = y}
local cooldowns, requests = {}, {}

local function framework()
  if Config.Framework ~= 'auto' then return Config.Framework end
  if GetResourceState('qbx_core') == 'started' then return 'qbox' end
  if GetResourceState('es_extended') == 'started' then return 'esx' end
  if GetResourceState('qb-core') == 'started' then return 'qb' end
  return 'standalone'
end

local fw = framework()
local ESX = fw == 'esx' and exports['es_extended']:getSharedObject() or nil
local QB = fw == 'qb' and exports['qb-core']:GetCoreObject() or nil

local function jobOf(src)
  if fw == 'esx' then
    local x = ESX.GetPlayerFromId(src)
    return x and x.job and x.job.name, x and x.job and x.job.grade or 0
  elseif fw == 'qb' then
    local x = QB.Functions.GetPlayer(src)
    local job = x and x.PlayerData.job
    return job and job.name, job and job.grade and (job.grade.level or job.grade) or 0
  elseif fw == 'qbox' then
    local x = exports.qbx_core:GetPlayer(src)
    local job = x and x.PlayerData and x.PlayerData.job
    return job and job.name, job and job.grade and (job.grade.level or job.grade) or 0
  end
end

local function hasJob(src)
  if IsPlayerAceAllowed(src, Config.AcePermission) then return true end
  local name, grade = jobOf(src)
  return name and Config.Jobs[name] ~= nil and tonumber(grade or 0) >= Config.Jobs[name] or false
end

local function authorized(src)
  return not Config.RestrictToJobs or hasJob(src)
end

local function notify(src, message, level)
  TriggerClientEvent('uncledev_tow:notify', src, message, level or 'inform')
end

local function ent(net)
  if type(net) ~= 'number' or net < 1 then return nil end
  local entity = NetworkGetEntityFromNetworkId(net)
  if entity == 0 or not DoesEntityExist(entity) or GetEntityType(entity) ~= 2 then return nil end
  return entity
end

local function near(a, b, distance)
  return #(GetEntityCoords(a) - GetEntityCoords(b)) <= distance
end

local function occupied(vehicle)
  for _, player in ipairs(GetPlayers()) do
    local ped = GetPlayerPed(tonumber(player))
    if ped ~= 0 and GetVehiclePedIsIn(ped, false) == vehicle then return true end
  end
  return false
end

local function allowed(src, carrier)
  if not authorized(src) then return false, 'You are not authorized to tow.' end
  local ped = GetPlayerPed(src)
  if ped == 0 or not DoesEntityExist(ped) then return false, 'Invalid player ped.' end
  if not near(ped, carrier, Config.InteractionDistance) then return false, 'Stand closer to the truck or trailer.' end
  if GetEntitySpeed(carrier) > Config.MaxTruckSpeed then return false, 'Stop the truck/trailer first.' end
  local cfg = Config.CarrierForModel(GetEntityModel(carrier))
  if not cfg then return false, 'This truck/trailer is not registered.' end
  return true, nil, cfg
end

local function cooldown(src)
  local now = os.time()
  if (cooldowns[src] or 0) > now then return false end
  cooldowns[src] = now + Config.CooldownSeconds
  return true
end

local function slotsCopy(carrierNet)
  local state = {}
  for number, cargo in pairs(loads[carrierNet] or {}) do state[number] = cargo end
  return state
end

local function syncSlots(carrierNet)
  local carrier = ent(carrierNet)
  if carrier then Entity(carrier).state:set('uncledevTowSlots', slotsCopy(carrierNet), true) end
end

local function releaseSlot(carrierNet, slot, shouldDetach)
  local entry = loads[carrierNet]
  local cargoNet = entry and entry[slot]
  if not cargoNet then return nil end
  entry[slot] = nil
  if not next(entry) then loads[carrierNet] = nil end
  reverse[cargoNet] = nil
  local cargo = ent(cargoNet)
  if cargo then
    Entity(cargo).state:set('uncledevTowCarrier', 0, true)
    Entity(cargo).state:set('uncledevTowSlot', 0, true)
  end
  syncSlots(carrierNet)
  if shouldDetach and cargo then TriggerClientEvent('uncledev_tow:detach', -1, carrierNet, cargoNet, slot) end
  return cargoNet
end

local function cargoAllowed(vehicle)
  if Config.CarrierForModel(GetEntityModel(vehicle)) then return false, 'Cannot load another registered tow carrier.' end
  local kind = GetVehicleType(vehicle)
  if kind ~= 'automobile' and kind ~= 'bike' and kind ~= 'quadbike' then
    return false, 'Only regular road vehicles can be secured.'
  end
  if not Config.AllowOccupiedVehicles and occupied(vehicle) then return false, 'Target vehicle must be unoccupied.' end
  return true
end

lib.callback.register('uncledev_tow:state', function(src, carrierNet)
  local carrier = ent(carrierNet)
  local ped = GetPlayerPed(src)
  if not carrier or ped == 0 or not near(ped, carrier, Config.InteractionDistance + 4.0) then return {} end
  if not Config.CarrierForModel(GetEntityModel(carrier)) then return {} end
  return slotsCopy(carrierNet)
end)

lib.callback.register('uncledev_tow:load', function(src, carrierNet, vehicleNet, slot, mode)
  local carrier, vehicle = ent(carrierNet), ent(vehicleNet)
  if not carrier or not vehicle or carrier == vehicle then return false, 'Invalid vehicles.' end
  local ok, err, cfg = allowed(src, carrier)
  if not ok then return false, err end
  slot = tonumber(slot)
  if not slot or slot % 1 ~= 0 or not cfg.slots[slot] then return false, 'Invalid loading spot.' end
  if loads[carrierNet] and loads[carrierNet][slot] then return false, 'That loading spot is already occupied.' end
  if reverse[vehicleNet] then return false, 'Vehicle is already secured to a carrier.' end
  if not near(carrier, vehicle, Config.MaxAttachDistance) then return false, 'Move the vehicle closer to the carrier.' end
  local targetOk, targetErr = cargoAllowed(vehicle)
  if not targetOk then return false, targetErr end
  if not cooldown(src) then return false, 'Please wait before towing again.' end

  loads[carrierNet] = loads[carrierNet] or {}
  loads[carrierNet][slot] = vehicleNet
  reverse[vehicleNet] = { carrierNet = carrierNet, slot = slot }
  Entity(vehicle).state:set('uncledevTowCarrier', carrierNet, true)
  Entity(vehicle).state:set('uncledevTowSlot', slot, true)
  syncSlots(carrierNet)
  -- 'winch' pulls the vehicle up the deck on the operator's client; 'instant' snaps it into place.
  local style = mode == 'instant' and 'instant' or 'winch'
  TriggerClientEvent('uncledev_tow:attach', src, carrierNet, vehicleNet, slot, style)
  return true, ('Vehicle secured in %s.'):format(cfg.slots[slot].label)
end)

lib.callback.register('uncledev_tow:unload', function(src, carrierNet, slot)
  local carrier = ent(carrierNet)
  if not carrier then return false, 'Invalid truck/trailer.' end
  local ok, err, cfg = allowed(src, carrier)
  if not ok then return false, err end
  slot = tonumber(slot)
  if not slot or not cfg.slots[slot] then return false, 'Invalid loading spot.' end
  if not loads[carrierNet] or not loads[carrierNet][slot] then return false, 'This loading spot is empty.' end
  if not cooldown(src) then return false, 'Please wait before towing again.' end
  releaseSlot(carrierNet, slot, true)
  return true, 'Vehicle unloaded.'
end)

local function nearImpound(ped)
  for _, point in ipairs(Config.ImpoundLocations) do
    if #(GetEntityCoords(ped) - point.coords) <= point.radius then return true, point.label end
  end
  return false
end

lib.callback.register('uncledev_tow:impound', function(src, carrierNet, slot)
  if not Config.EnableImpound then return false, 'Impound is disabled.' end
  local carrier = ent(carrierNet)
  if not carrier then return false, 'Invalid truck/trailer.' end
  local ok, err, cfg = allowed(src, carrier)
  if not ok then return false, err end
  slot = tonumber(slot)
  if not slot or not cfg.slots[slot] then return false, 'Invalid loading spot.' end
  local ped = GetPlayerPed(src)
  local inside, location = nearImpound(ped)
  if not inside then return false, 'Go to a configured impound location.' end
  local net = loads[carrierNet] and loads[carrierNet][slot]
  local cargo = net and ent(net)
  if not cargo then return false, 'No valid vehicle in that spot.' end
  if occupied(cargo) then return false, 'Vehicle is occupied.' end
  if not cooldown(src) then return false, 'Please wait.' end
  releaseSlot(carrierNet, slot, true)
  Wait(300) -- give the controller a chance to detach before server deletion
  if DoesEntityExist(cargo) then DeleteEntity(cargo) end
  if DoesEntityExist(cargo) then return false, 'Vehicle deletion failed; it was unloaded instead.' end

  if Config.ImpoundReward > 0 and hasJob(src) then
    if fw == 'esx' then
      local x = ESX.GetPlayerFromId(src)
      if x then x.addAccountMoney('bank', Config.ImpoundReward) end
    elseif fw == 'qb' then
      local x = QB.Functions.GetPlayer(src)
      if x then x.Functions.AddMoney('bank', Config.ImpoundReward, 'tow-impound') end
    elseif fw == 'qbox' then
      exports.qbx_core:AddMoney(src, 'bank', Config.ImpoundReward, 'tow-impound')
    end
  end
  print(('[UncleDev Tow] %s (#%s) impounded a vehicle at %s'):format(GetPlayerName(src), src, location))
  return true, 'Vehicle impounded at ' .. location
end)

RegisterNetEvent('uncledev_tow:request', function(message)
  local src = source
  if not Config.UseDispatch or type(message) ~= 'string' then return end
  message = message:sub(1, 110)
  local now = os.time()
  if requests[src] and now - requests[src] < 60 then return notify(src, 'One tow request per minute.', 'error') end
  requests[src] = now
  local ped = GetPlayerPed(src)
  if ped == 0 then return end
  local coords = GetEntityCoords(ped)
  for _, player in ipairs(GetPlayers()) do
    local id = tonumber(player)
    if not Config.DispatchJobsOnly or hasJob(id) then
      TriggerClientEvent('uncledev_tow:dispatch', id, src, GetPlayerName(src), message, coords)
    end
  end
  notify(src, 'Tow assistance request sent.', 'success')
end)

AddEventHandler('playerDropped', function()
  cooldowns[source], requests[source] = nil, nil
end)

CreateThread(function()
  while true do
    Wait(8000)
    for carrierNet, entries in pairs(loads) do
      if not ent(carrierNet) then
        for slot in pairs(entries) do releaseSlot(carrierNet, slot, true) end
      else
        for slot, cargoNet in pairs(entries) do
          if not ent(cargoNet) then releaseSlot(carrierNet, slot, false) end
        end
      end
    end
  end
end)

AddEventHandler('onResourceStop', function(resource)
  if resource ~= GetCurrentResourceName() then return end
  for carrierNet, entries in pairs(loads) do
    for slot, cargoNet in pairs(entries) do
      local cargo = ent(cargoNet)
      if cargo then
        Entity(cargo).state:set('uncledevTowCarrier', 0, true)
        Entity(cargo).state:set('uncledevTowSlot', 0, true)
      end
    end
    local carrier = ent(carrierNet)
    if carrier then Entity(carrier).state:set('uncledevTowSlots', {}, true) end
  end
end)

-- Legacy-friendly: first loaded vehicle for carrier, and true when cargo is secured.
exports('GetTowedVehicle', function(carrierNet)
  for _, cargoNet in pairs(loads[carrierNet] or {}) do return cargoNet end
  return nil
end)
exports('IsVehicleTowed', function(vehicleNet) return reverse[vehicleNet] ~= nil end)
exports('GetCarrierLoads', function(carrierNet) return slotsCopy(carrierNet) end)

-- ============================================================
-- IN-GAME CONFIGURATOR (/towedit)
-- Saved entries live in data/carriers.json and are layered over shared/vehicles.lua.
-- ============================================================
local DATA_FILE = 'data/carriers.json'

local function loadOverrides()
  local raw = LoadResourceFile(GetCurrentResourceName(), DATA_FILE)
  local ok, decoded = false, nil
  if raw and raw ~= '' then ok, decoded = pcall(json.decode, raw) end
  local valid = {}
  for _, entry in ipairs(ok and type(decoded) == 'table' and decoded or {}) do
    local normalized, err = Config.NormalizeEntry(entry)
    if normalized then
      valid[#valid + 1] = normalized
    else
      print(('[UncleDev Tow] Skipped a saved carrier: %s'):format(err or 'invalid entry'))
    end
  end
  Config.Overrides = valid
  Config.RebuildCarriers()
end

local function saveOverrides()
  local saved = SaveResourceFile(GetCurrentResourceName(), DATA_FILE, json.encode(Config.Overrides), -1)
  if saved then TriggerClientEvent('uncledev_tow:registry', -1, Config.Overrides) end
  return saved
end

local function canEdit(src)
  return IsPlayerAceAllowed(src, Config.AdminPermission)
end

RegisterNetEvent('uncledev_tow:requestRegistry', function()
  TriggerClientEvent('uncledev_tow:registry', source, Config.Overrides)
end)

lib.callback.register('uncledev_tow:editor:check', function(src)
  return canEdit(src)
end)

lib.callback.register('uncledev_tow:editor:save', function(src, input)
  if not canEdit(src) then return false, 'You are not allowed to configure towing.' end
  local normalized, err = Config.NormalizeEntry(input)
  if not normalized then return false, err end

  local list = {}
  for _, entry in ipairs(Config.Overrides) do
    if entry.model ~= normalized.model then list[#list + 1] = entry end
  end
  list[#list + 1] = normalized
  Config.Overrides = list
  Config.RebuildCarriers()

  if not saveOverrides() then
    loadOverrides()
    return false, 'Could not write data/carriers.json. Check the server file permissions.'
  end
  print(('[UncleDev Tow] %s saved carrier %s'):format(GetPlayerName(src), normalized.model))
  return true, ('Saved %s.'):format(normalized.label)
end)

lib.callback.register('uncledev_tow:editor:reset', function(src, model)
  if not canEdit(src) then return false, 'You are not allowed to configure towing.' end
  if type(model) ~= 'string' then return false, 'Invalid model.' end

  local list = {}
  for _, entry in ipairs(Config.Overrides) do
    if entry.model ~= model then list[#list + 1] = entry end
  end
  Config.Overrides = list
  Config.RebuildCarriers()

  if not saveOverrides() then
    loadOverrides()
    return false, 'Could not write data/carriers.json. Check the server file permissions.'
  end
  return true, 'Settings reset.'
end)

loadOverrides()

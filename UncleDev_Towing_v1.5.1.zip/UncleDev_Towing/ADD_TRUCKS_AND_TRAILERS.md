# EASY SETUP: ADD TRUCKS & TRAILERS

Open: `UncleDev_Towing/shared/vehicles.lua`

## 1. Find the spawn name

Stand next to the custom vehicle or sit inside it. Run `/towmodel`. Copy the spawn name shown on screen or in F8.

## 2. Add ONE LINE near the end of `shared/vehicles.lua`

Flatbed:

```lua
Config.AddTruck('ford_f650', 'flatbed', {0.0, -3.1, 1.05}, 'F650 Flatbed')
```

Hook / wheel lift:

```lua
Config.AddTruck('heavywrecker', 'wheel_lift', {0.0, -4.0, 0.15}, 'Heavy Wrecker')
```

Car-hauling trailer:

```lua
Config.AddTrailer('carhauler', 'trailer', {0.0, -2.5, 1.25}, 'Car Hauler')
```

The names above are **examples**; those add-on models must actually be installed on your server. The offset values are **starting points**, not verified measurements for those models.

## 3. Adjust the three numbers if needed

- First number = X = left (-) / right (+)
- Second number = Y = rear (-) / front (+)
- Third number = Z = up (+) / down (-)

A truck with a longer bed might need a different Y position. A higher trailer deck needs a higher Z value. Restart the resource after changing the config.

## 4. Optional: more than one vehicle per trailer

```lua
Config.AddTrailer('bigcarhauler', 'trailer', {0.0, -2.0, 1.3}, 'Big Car Hauler')
Config.SetSlots('bigcarhauler', {
  { label = 'Front', offset = {0.0, 2.0, 1.4} },
  { label = 'Rear',  offset = {0.0, -3.5, 1.4} }
})
```

Use F6, choose the trailer, and then choose the available spot. Up to eight independently controlled spots are supported; customize positions to avoid overlapping vehicles.

## 5. Test it

1. Spawn your truck and trailer (using your existing vehicle spawner).
2. Stop and get out.
3. Position an unoccupied car next to the loading deck.
4. Press `F6` / type `/tow`.
5. Choose your truck/trailer and use Load.

## Notes

- Registration does NOT add vehicles to a dealership/garage/spawn menu; it simply tells the towing script which existing models can carry vehicles.
- Trailer hitch/physical coupling to a towing rig is controlled by GTA V vehicle model/`vehicles.meta` configuration and is separate from securing cargo on a trailer.
- `tr2` is registered by default as a known GTA transport trailer. Its deck offset is a tuneable starting value.
- Only install one copy of `UncleDev_Towing`; disable the old release when you update.
